const {chromium}=require('/usr/share/code/resources/app/node_modules/playwright-core');
const FPS=10,L={hero:6,way:4.8,tools:4.8,intel:6,run:5};
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox']});
for(const [w,label] of [[1000,'desktop'],[390,'mobile']]){const page=await b.newPage({viewport:{width:w,height:1500},deviceScaleFactor:1});
await page.goto('file:///downloads/gh2/index.html');await page.addStyleTag({content:'.panel{box-shadow:none!important}'});
const sel={hero:'#p-hero',way:'#p-way',tools:'#p-tools',intel:'#p-intel',run:'#p-run'};
for(const name of Object.keys(sel)){const out=`/downloads/gh2/export/${name}-${label}`;require('fs').mkdirSync(out,{recursive:true});
const n=Math.round(L[name]*FPS);for(let f=0;f<n;f++){await page.evaluate(({f,name,t})=>setT(name,t),{f,name,t:f/FPS});await page.locator(sel[name]).screenshot({path:out+'/'+String(f).padStart(3,'0')+'.png'});}}
await page.close()}await b.close()})();
